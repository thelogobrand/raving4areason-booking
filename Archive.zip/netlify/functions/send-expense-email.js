export async function handler(event) {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
    }

    const { expense } = JSON.parse(event.body || "{}");
    if (!expense) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing expense" }) };
    }

    const RESEND_API_KEY = process.env.RESEND_API_KEY;
    if (!RESEND_API_KEY) {
      return { statusCode: 500, body: JSON.stringify({ error: "RESEND_API_KEY missing" }) };
    }

    const mentorName = expense.mentor_display_name || expense.mentor || "Mentor";
    const amount = Number(expense.amount || 0).toFixed(2);
    const details = expense.expense_type === "mileage"
      ? `${expense.miles || 0} miles`
      : (expense.category || "Expense");

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: "Raving 4 A Reason <onboarding@resend.dev>",
        to: ["Raving4areason1@outlook.com"],
        subject: `New expense submitted - ${mentorName}`,
        html: `
          <h2>New Mentor Expense</h2>
          <p><strong>Mentor:</strong> ${mentorName}</p>
          <p><strong>Amount:</strong> £${amount}</p>
          <p><strong>Date:</strong> ${expense.expense_date || ""}</p>
          <p><strong>Type:</strong> ${details}</p>
          <p><strong>Reason:</strong> ${expense.reason || ""}</p>
          ${expense.receipt_url ? `<p><a href="${expense.receipt_url}">View receipt</a></p>` : ""}
        `
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("Resend expense email error:", data);
      return { statusCode: response.status, body: JSON.stringify(data) };
    }

    return { statusCode: 200, body: JSON.stringify({ success: true, data }) };
  } catch (error) {
    console.error("Expense email error:", error);
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
}
